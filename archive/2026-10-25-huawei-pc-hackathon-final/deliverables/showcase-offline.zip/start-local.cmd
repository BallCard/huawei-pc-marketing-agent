@echo off
setlocal
cd /d "%~dp0"

rem Prefer a local HTTP server so all browsers load CSS, fonts, images and scripts consistently.
where py >nul 2>&1
if %errorlevel%==0 (
  start "华章有据离线展示服务" /b py -m http.server 8765 --bind 127.0.0.1
  timeout /t 1 /nobreak >nul
  start "" http://127.0.0.1:8765/index.html
  exit /b 0
)

where python >nul 2>&1
if %errorlevel%==0 (
  start "华章有据离线展示服务" /b python -m http.server 8765 --bind 127.0.0.1
  timeout /t 1 /nobreak >nul
  start "" http://127.0.0.1:8765/index.html
  exit /b 0
)

rem Fallback for machines without Python. The offline package uses relative paths.
start "" index.html
